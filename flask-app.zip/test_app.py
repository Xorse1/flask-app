def test_home():
    assert True